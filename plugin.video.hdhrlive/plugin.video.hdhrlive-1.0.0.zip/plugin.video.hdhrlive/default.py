import xbmc, xbmcplugin, xbmcgui, xbmcaddon, requests, json, urllib, urlparse

addon_handle = int(sys.argv[1])

def createMainMenu():
    url = xbmcaddon.Addon().getSetting("url")
    r = requests.get(url)
    channels = json.loads(r.content)
    for chan in channels:
        labels = {'title': chan['name'], 'mediatype': 'video'}
        chan['labels'] = labels
        item = xbmcgui.ListItem(chan['name'])
        item.setInfo('Video', labels)
        item.setProperty('IsPlayable', 'true')
        path = sys.argv[0] + "?" + urllib.urlencode(chan)
        xbmcplugin.addDirectoryItem(addon_handle, path, item, False)
    xbmcplugin.endOfDirectory(addon_handle)
    return None

def playChannel(values):
    li = xbmcgui.ListItem(path='udp://:5000')
    li.setInfo('video', infoLabels=values['labels'])
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    try:
        r = requests.get(values['url'])
    except requests.exceptions.InvalidSchema:
        xbmc.log('Invalid schema error setting channel', xbmc.LOGWARNING)
    return None

if len(sys.argv[2]) == 0:
    createMainMenu()
else:
    values = dict(urlparse.parse_qsl(sys.argv[2][1:]))
    playChannel(values)
