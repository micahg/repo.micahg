import concacaf

streams = concacaf.get_streams()

print(streams)