# plugin.video.onesoccer
Canadian Premier League Soccer Live Streaming

## To Do

* Finish the menus for Highlights and Match Replays
