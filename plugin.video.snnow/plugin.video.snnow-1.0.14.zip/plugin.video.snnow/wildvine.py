import urllib, urllib2
from cookies import Cookies

class Wildvine:

    PROXY_URI = 'https://prod-lic2widevine.sd-ngp.net/proxy'

    @staticmethod
    def first(token):
        jar = Cookies.getCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(jar),
                                      urllib2.HTTPHandler(debuglevel=1),
                                      urllib2.HTTPSHandler(debuglevel=1))

        opener.addheaders = [('path', '/proxy'),
                             ('pragma', 'no-cache'),
                             ('origin', 'https://now.sportsnet.ca'),
                             ('accept-encoding', 'gzip, deflate, br'),
                             ('accept-language', 'en-CA,en-GB;q=0.8,en-US;q=0.6,en;q=0.4'),
                             ('authorization', 'bearer {}'.format(token)),
                             ('accept', '*/*'),
                             ('cache-control', 'no-cache'),
                             ('content-type', ''),
                             ('authority', 'prod-lic2widevine.sd-ngp.net'),
                             ('referer', 'https://now.sportsnet.ca/'),
                             ('scheme', 'https')]

        try:
            resp = opener.open(Wildvine.PROXY_URI, '')
        except urllib2.URLError, e:
            print e.args
            return False
        Cookies.saveCookieJar(jar)

        resp = resp.read()

        return resp