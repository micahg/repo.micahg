# plugin.video.onesoccer
Canadian Premier League Soccer Live Streaming
